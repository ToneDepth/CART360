/*----------------------------------------------------------------------------*/
/*------------------------------ SHIFT REGISTER ------------------------------*/
/*----------------------------------------------------------------------------*/
/*----------      IMPLEMENT THE SHIFT REGISTER FUNCTIONALITY        ----------*/
/*----------          ******** ATTRIBUTE YOUR CODE ********         ----------*/
/*----------------------------------------------------------------------------*/

#ifndef SHIFTREGISTER_H_
#define SHIFTREGISTER_H_

#include "Constants.h"

/* SHIFT REGISTER IC PIN OUTS
        __
  Q1 -|    |- VCC
  Q2 -|    |- Q0
  Q3 -|    |- DS
  Q4 -|    |- OE
  Q5 -|    |- ST_CP
  Q6 -|    |- SH_CP
  Q7 -|    |- MR
  GND -| __ |- Q'

  Key:
  Q0 - Q7: Parallel Out Pins
  Q': Cascade Pin
  DS: Serial Data In Pin
  OE: Output Enable (GND)
  ST_CP: Latch Pin
  SH_CP: Clock Pin
  MR: Master Reset (VCC)
*/

/* PINS FOR SHIFT REG */
// ST_CP of 74HC595
#define LATCH_PIN 6
// SH_CP of 74HC595
#define CLOCK_PIN 8
// DS of 74HC595
#define DATA_PIN 7

/* CONSTANT FOR EMPTY*/
#define EMPTY B00000001

/* DEFINE AND INITIALIZE THE ARRAY WITH THE NECESSARY VALUES */
// Hex Character from 0 - F
byte hexArray[16] = {B11111100, B01100000, B11011010, B11110010, B01100110, B10110110, B10111110, B11100000, B11111110,
                     B11110110, B11101110, B00111110, B10011100, B01111010, B10011110, B10001110
                    };
int arrayMode;
const char common = 'c';    // common cathode
bool decPt = true;  // decimal point display flag

int controlInc;
int controlMode;
int bits;

void setupShiftRegister() {
  pinMode(LATCH_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);
  pinMode(DATA_PIN, OUTPUT);

  pinMode(POT_PIN, INPUT);
}

/******************sendToShiftRegister *******************************
  TODO:: IMPLEMENT THE FUNCTIONALITY TO SEND THE CORRECT DATA TO
  SHIFT REG - BASED ON THE POT VAL
********************************************************************/
int sendToShiftRegister(int pot) {
  switch (pot) {
case 0:
      return B11111100;
      break;
    case 1:
      return B01100000;
      break;
    case 2:
      return B11011010;
      break;
    case 3:
      return B11110010;
      break;
    case 4:
      return B01100110;
      break;
    case 5:
      return B10110110;
      break;
    case 6:
      return B10111110;
      break;
    case 7:
      return B11100000;
      break;
    case 8:
      return B11111110;
      break;
    case 9:
      return B11110110;
      break;
    case 10:
      return B11101110; // Hexidecimal A
      break;
    case 11:
      return B00111110; // Hexidecimal B
      break;
    case 12:
      return B10011100; // Hexidecimal C or use for Centigrade
      break;
    case 13:
      return B01111010; // Hexidecimal D
      break;
    case 14:
      return B10011110; // Hexidecimal E
      break;
    case 15:
      return B10001110; // Hexidecimal F or use for Fahrenheit
      break;
    default:
      return B10010010; // Error condition, displays three vertical bars
      break;
  }
}

/******************READ FROM POT*********************************
  TO DO:: GET VALUE FROM POT AND ENSURE THE VALUE RETURNED IS A VALID VALUE
********************************************************************/
int getAnalog() {
  controlMode = analogRead(POT_PIN);


  bits = sendToShiftRegister(arrayMode) ;
  digitalWrite(LATCH_PIN, LOW);  // prepare shift register for data
  shiftOut(DATA_PIN, CLOCK_PIN, LSBFIRST, B11011010); // send data
  digitalWrite(LATCH_PIN, HIGH); // update display


}

void myfnUpdateDisplay() {

  digitalWrite(LATCH_PIN, LOW);  // prepare shift register for data
  shiftOut(DATA_PIN, CLOCK_PIN, LSBFIRST, B11011010); // send data
  digitalWrite(LATCH_PIN, HIGH); // update display
}

#endif /* SHIFTREGISTER_H_ */
